# -*- coding: utf-8 -*-
#
#   Copyright (c) 2021-2022 Billy2011 @ vuplus-support.org
#
#   SPDX-License-Identifier: GPL-2.0-or-later
#   See LICENSES/README.md for more information.
#
#   PlutoTV is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   PlutoTV is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with PlutoTV.  If not, see <http://www.gnu.org/licenses/>.
#

from __future__ import absolute_import
import os

import six.moves.urllib.parse
from . import _, maybe_encode
from Tools.Directories import fileExists
from twisted.internet import defer
from twisted.web.client import downloadPage

try:
	from twisted.internet import ssl
	from twisted.internet._sslverify import ClientTLSOptions

	sslverify = True
except ImportError:
	sslverify = False


class PlutoDownloader(object):

	if sslverify:

		class SNIFactory(ssl.ClientContextFactory):
			def __init__(self, hostname=None):
				self.hostname = hostname

			def getContext(self):
				ctx = self._contextFactory(self.method)
				if self.hostname:
					ClientTLSOptions(self.hostname, ctx)
				return ctx

		__SNIFactory__ = SNIFactory

	def start(self, filename, sourcefile, overwrite=False):
		if not filename or not sourcefile:
			return defer.fail(Exception("[PlutoDownloader] Wrong arguments"))

		if not overwrite and fileExists(filename) and os.path.getsize(filename):
			return defer.succeed(filename)

		if sourcefile.startswith("https") and sslverify:
			parsed_uri = six.moves.urllib.parse.urlparse(sourcefile)
			domain = parsed_uri.hostname
			sniFactory = self.__SNIFactory__(domain)
			return downloadPage(sourcefile.encode("utf-8"), filename, sniFactory, timeout=30).addCallbacks(
				self.afterDownload, self.downloadFail, callbackArgs=(filename,), errbackArgs=(sourcefile,)
			)
		else:
			return downloadPage(maybe_encode(sourcefile), filename, timeout=30).addCallback(
				self.afterDownload, filename).addErrback(downloadFail, sourcefile)

	def afterDownload(self, result, filename):
		print("[PlutoDownloader] afterDownload", filename)
		try:
			if not os.path.getsize(filename):
				raise Exception("[PlutoDownloader] File is empty")
		except Exception as e:
			raise (e)
		else:
			return filename

	def downloadFail(self, failure, sourcefile):
		print("[PlutoDownloader] download failed, failure: {0}\nsourcefile: {1}:".format(failure, sourcefile))
		return failure
